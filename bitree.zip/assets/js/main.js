(function() {
  "use strict";

  /**
   * Apply .scrolled class to the body as the page is scrolled down
   */
  function toggleScrolled() {
    const selectBody = document.querySelector('body');
    const selectHeader = document.querySelector('#header');
    if (!selectHeader.classList.contains('scroll-up-sticky') && !selectHeader.classList.contains('sticky-top') && !selectHeader.classList.contains('fixed-top')) return;
    window.scrollY > 100 ? selectBody.classList.add('scrolled') : selectBody.classList.remove('scrolled');
  }

  document.addEventListener('scroll', toggleScrolled);
  window.addEventListener('load', toggleScrolled);

  /**
   * Mobile nav toggle
   */
  const mobileNavToggleBtn = document.querySelector('.mobile-nav-toggle');

  function mobileNavToogle() {
    document.querySelector('body').classList.toggle('mobile-nav-active');
    mobileNavToggleBtn.classList.toggle('is-open');
    const toggleIcon = mobileNavToggleBtn.querySelector('.ui-icon');
    if (toggleIcon) {
      toggleIcon.classList.toggle('ui-icon-list', !mobileNavToggleBtn.classList.contains('is-open'));
      toggleIcon.classList.toggle('ui-icon-x', mobileNavToggleBtn.classList.contains('is-open'));
      if (window.BitreeIcons) window.BitreeIcons.render(toggleIcon);
    }
    mobileNavToggleBtn.setAttribute(
      'aria-label',
      mobileNavToggleBtn.classList.contains('is-open') ? 'Close menu' : 'Open menu'
    );
  }
  if (mobileNavToggleBtn) {
    mobileNavToggleBtn.addEventListener('click', mobileNavToogle);
  }

  /**
   * Hide mobile nav on same-page/hash links
   */
  document.querySelectorAll('#navmenu a').forEach(navmenu => {
    navmenu.addEventListener('click', () => {
      if (document.querySelector('.mobile-nav-active')) {
        mobileNavToogle();
      }
    });

  });

  /**
   * Toggle mobile nav dropdowns
   */
  document.querySelectorAll('.navmenu .toggle-dropdown').forEach(navmenu => {
    navmenu.addEventListener('click', function(e) {
      e.preventDefault();
      this.parentNode.classList.toggle('active');
      this.parentNode.nextElementSibling.classList.toggle('dropdown-active');
      e.stopImmediatePropagation();
    });
  });

  /**
   * Scroll top button
   */
  let scrollTop = document.querySelector('.scroll-top');

  function toggleScrollTop() {
    if (scrollTop) {
      window.scrollY > 100 ? scrollTop.classList.add('active') : scrollTop.classList.remove('active');
    }
  }
  scrollTop.addEventListener('click', (e) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });

  window.addEventListener('load', toggleScrollTop);
  document.addEventListener('scroll', toggleScrollTop);

  /**
   * Animation on scroll function and init
   */
  function aosInit() {
    AOS.init({
      duration: 600,
      easing: 'ease-in-out',
      once: true,
      mirror: false
    });
  }
  window.addEventListener('load', aosInit);

  /**
   * Initiate glightbox
   */
  const glightbox = GLightbox({
    selector: '.glightbox'
  });

  /**
   * Initiate Pure Counter
   */
  new PureCounter();

  /**
   * Init typed.js
   */
  const selectTyped = document.querySelector('.typed');
  if (selectTyped) {
    let typed_strings = selectTyped.getAttribute('data-typed-items');
    typed_strings = typed_strings.split(',');
    new Typed('.typed', {
      strings: typed_strings,
      loop: true,
      typeSpeed: 100,
      backSpeed: 50,
      backDelay: 2000
    });
  }

  /**
   * Init swiper sliders
   */
  function initSwiper() {
    document.querySelectorAll(".init-swiper").forEach(function(swiperElement) {
      let config = JSON.parse(
        swiperElement.querySelector(".swiper-config").innerHTML.trim()
      );

      if (swiperElement.classList.contains("swiper-tab")) {
        initSwiperWithCustomPagination(swiperElement, config);
      } else {
        new Swiper(swiperElement, config);
      }
    });
  }

  window.addEventListener("load", initSwiper);

  /**
   * Contact popup
   */
  function initContactPopup() {
    const popup = document.querySelector('#contact-popup');
    if (!popup) return;

    const triggers = document.querySelectorAll('.contact-popup-trigger, a[href="#contact-popup"]');
    const closeControls = popup.querySelectorAll('[data-contact-popup-close]');
    const firstField = popup.querySelector('input:not([type="hidden"]):not([tabindex="-1"]), textarea, button');
    let previousFocus = null;

    function openPopup(event) {
      if (event) event.preventDefault();
      previousFocus = document.activeElement;
      popup.classList.add('is-open');
      popup.setAttribute('aria-hidden', 'false');
      document.body.classList.add('contact-popup-open');
      if (window.BitreeIcons) window.BitreeIcons.renderAll(popup);
      setTimeout(() => {
        if (firstField) firstField.focus();
      }, 50);
    }

    function closePopup() {
      popup.classList.remove('is-open');
      popup.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('contact-popup-open');
      if (previousFocus && typeof previousFocus.focus === 'function') {
        previousFocus.focus();
      }
    }

    triggers.forEach((trigger) => {
      trigger.addEventListener('click', openPopup);
    });

    closeControls.forEach((control) => {
      control.addEventListener('click', closePopup);
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && popup.classList.contains('is-open')) {
        closePopup();
      }
    });
  }

  window.addEventListener('load', initContactPopup);

  /**
   * Local tab controller for feature tabs
   */
  function initFeatureTabs() {
    document.querySelectorAll('.features-tabs .tabs-wrapper').forEach((tabsWrapper) => {
      const tabLinks = Array.from(tabsWrapper.querySelectorAll('.nav-link[data-tab-target]'));
      const tabPanes = Array.from(tabsWrapper.querySelectorAll('.tab-content > .tab-pane'));

      function activateTab(tabLink) {
        const targetSelector = tabLink.getAttribute('data-tab-target');
        const targetPane = targetSelector ? tabsWrapper.querySelector(targetSelector) : null;
        if (!targetPane) return;

        tabLinks.forEach((link) => {
          const isActive = link === tabLink;
          link.classList.toggle('active', isActive);
          link.classList.toggle('show', isActive);
          link.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });

        tabPanes.forEach((pane) => {
          const isActive = pane === targetPane;
          pane.classList.toggle('active', isActive);
          pane.classList.toggle('show', isActive);
        });
      }

      tabLinks.forEach((tabLink) => {
        tabLink.addEventListener('click', (event) => {
          event.preventDefault();
          activateTab(tabLink);
        });
      });

      activateTab(tabLinks.find((link) => link.classList.contains('active')) || tabLinks[0]);
    });
  }

  window.addEventListener('load', initFeatureTabs);

  /**
   * Frequently Asked Questions Toggle
   */
  document.querySelectorAll('.faq-item h3, .faq-item .faq-toggle, .faq-item .faq-header').forEach((faqItem) => {
    faqItem.addEventListener('click', () => {
      faqItem.parentNode.classList.toggle('faq-active');
    });
  });

  /**
   * Correct scrolling position upon page load for URLs containing hash links.
   */
  window.addEventListener('load', function(e) {
    if (window.location.hash) {
      if (document.querySelector(window.location.hash)) {
        setTimeout(() => {
          let section = document.querySelector(window.location.hash);
          let scrollMarginTop = getComputedStyle(section).scrollMarginTop;
          window.scrollTo({
            top: section.offsetTop - parseInt(scrollMarginTop),
            behavior: 'smooth'
          });
        }, 100);
      }
    }
  });

  /**
   * Navmenu Scrollspy
   */
  let navmenulinks = document.querySelectorAll('.navmenu a');

  function navmenuScrollspy() {
    navmenulinks.forEach(navmenulink => {
      if (!navmenulink.hash) return;
      let section = document.querySelector(navmenulink.hash);
      if (!section) return;
      let position = window.scrollY + 200;
      if (position >= section.offsetTop && position <= (section.offsetTop + section.offsetHeight)) {
        document.querySelectorAll('.navmenu a.active').forEach(link => link.classList.remove('active'));
        navmenulink.classList.add('active');
      } else {
        navmenulink.classList.remove('active');
      }
    })
  }
  window.addEventListener('load', navmenuScrollspy);
  document.addEventListener('scroll', navmenuScrollspy);

})();
